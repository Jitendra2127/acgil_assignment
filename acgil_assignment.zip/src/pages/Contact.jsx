const Contact = () => {
  return <h1> This is Contact Page</h1>;
};

export default Contact;
