const Products = () => {
  return <h1>This is Products Page</h1>;
};

export default Products;
