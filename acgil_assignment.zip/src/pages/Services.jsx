const Services = () => {
  return <h1>This is Services Page</h1>;
};

export default Services;
